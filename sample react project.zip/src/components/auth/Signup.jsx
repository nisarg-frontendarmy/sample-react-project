const Signup = () => {
    return (
        <div className="auth-path-container">
            <h2>Please Sign Up Your Account</h2>
        </div>
    )
}
export default Signup;